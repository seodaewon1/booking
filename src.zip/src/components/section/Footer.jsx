import React from 'react'

const Footer = () => {
    return (
        <footer id='footer' role='contentinfo'>
            test
        </footer>
    )
}

export default Footer
