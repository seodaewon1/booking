export const headermenus = [

    {
        title: "한식조리기능사",
        src: "/hansik"
    },
    {
        title: "제과기능사",
        src: "/jegwa"
    },
    {
        title: "정보처리기능사",
        src: "/jeongboGineung"
    },
    {
        title: "정보처리기사",
        src: "/jeongboGisa"
    },
    {
        title: "전기기사",
        src: "/JeongiGisa"
    },
    {
        title: "전기산업기사",
        src: "/JeongiSaneop"
    },
    {
        title: "제빵기능사",
        src: "/Jeppang"
    },
    {
        title: "지게차운전기능사",
        src: "/Jige"
    },
    {
        title: "건설안전기사",
        src: "/Geonseol"
    },
    {
        title: "미용사(일반)",
        src: "/iiban"
    },
    {
        title: "미용사(메이크업)",
        src: "/Makeup"
    },
    {
        title: "미용사(네일)",
        src: "/Nail"
    },
    {
        title: "미용사(피부)",
        src: "/Pibu"
    },
    // {
    //     title: "소방설비기사 ",
    //     src: "/Sobang"
    // },
];

export const detailmenus = [
    {
        title: "교보문고",
        src: "/kyobo"
    },
    {
        title: "yes24",
        src: "/yes24"
    },
    {
        title: "알라딘",
        src: "/aladin"
    },

];

export default detailmenus;
