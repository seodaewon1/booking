import React from 'react'
import BookList from '../components/section/Booklist';

const Home = () => {
  return (
    <BookList />
  )
}

export default Home