import React from 'react'
import BookSlide from '../section/BookSlide'
const Main = (props) => {
    return (
        <div id='Main'>

            <BookSlide />
        </div>
    )
}

export default Main
